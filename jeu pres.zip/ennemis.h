    #include "structs.h"

  extern Hero ennemi[];
  extern Gestion jeu;
  extern SDL_Surface *loadImage(char *name);
  extern Map map;
  extern Hero jonathan;
  extern int collide(Hero *player, Hero *monster);
  extern int collision_back (Hero *a);

