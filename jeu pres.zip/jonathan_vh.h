    #include "structs.h"

    extern Gestion jeu;
    extern Hero jonathan_vh;
    extern Input input;
    extern SDL_Surface *loadImage(char *name);
    extern void centerScrollingOnPlayer(void);
    extern Map map;

