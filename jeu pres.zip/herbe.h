#include "structs.h"

extern Herbe herbe[nbre_herbes];
extern Hero jonathan;
extern Map map;
extern Input input;
extern Gestion jeu;
