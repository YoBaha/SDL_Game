#include "defs.h"
#include "structs.h"

extern Hero jonathan;
extern Map map;
extern Map ea;
