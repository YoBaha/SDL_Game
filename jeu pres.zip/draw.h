 #include "structs.h"


   extern void drawanimatedjonathan_vh(void);
   extern void scrolling_map(void);
   extern void drawAnimatedEnnemis(void);
   extern void draw_etoiles(void);
   extern void afficher_vie(void);
   extern void draw_herbes (void);
   extern void draw_statues(void);
   extern void draw_herbes2 (void);
  
  extern Hero jonathan;
  extern Gestion jeu;
  extern Map map;
  extern Herbe herbe;
