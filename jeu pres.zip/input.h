 #include "structs.h"
 SDL_Event event; 
 extern Input input;
 extern Hero jonathan;
