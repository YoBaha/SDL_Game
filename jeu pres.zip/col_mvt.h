 #include "structs.h"

extern Map map ;
