
    #include "structs.h"

    extern Gestion jeu;
    extern Hero jonathan;
    extern Input input;
    extern SDL_Surface *loadImage(char *name);
    extern centerScrollingOnJonathan_vh(void);
    extern int collision_back (Hero *a);
    extern void afficher_vie(void);
    extern int update_herbes (void);
    extern int update_statues(void);
    extern Map map;
    extern Herbe herbe;
