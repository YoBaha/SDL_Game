#include "structs.h"

extern Map map ;
extern Gestion jeu;
extern Map ea;
