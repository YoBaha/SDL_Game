
   #include "structs.h"

   extern SDL_Surface *loadImage(char *name);
   extern Map map;
   extern Gestion jeu;
   extern Map ea ;
