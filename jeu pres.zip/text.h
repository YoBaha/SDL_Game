#include "structs.h"

extern Hero jonathan;
extern Gestion jeu;

