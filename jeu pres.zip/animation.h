    #include "structs.h"

    extern Gestion jeu;
    extern Hero jonathan_vh;
    extern Hero jonathan;


    extern void drawjonathan_vh(void);
