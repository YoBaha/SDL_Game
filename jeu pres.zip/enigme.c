#include "enigme_jeu.h"

int main(int argc, char *argv[])
{
    enigme();
    return 0;
}
