#include "structs.h"

extern  Etoile etoile[] ;
extern  SDL_Surface *loadImage(char *name);
extern  int col_et(Hero *player, Etoile *etoile) ;
extern  void drawImage(SDL_Surface *image, int x, int y);
extern  Gestion jeu;
extern  Hero jonathan;
extern  Map map;
